#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import scrapy
from ..items import EdaWebscrapingItem


class QuotesSpider(scrapy.Spider):
    name = "eda_webscrape"
    page_number = 2

    start_urls = [
        'https://www.amazon.in/s?i=electronics&bbn=1389401031&rh=n%3A1389401031%2Cp_89%3ARedmi%7CSamsung&dc&qid=1611369312&rnid=3837712031&ref=sr_nr_p_89_3'
    ]

    def parse(self, response):
        items = EdaWebscrapingItem()
        modelName = response.css('.a-text-normal::text').getall()
        price = response.css('.a-price-whole::text').getall()
 
        items['modelName'] = []
        items['price'] = price
        data = response.css('.a-row span::attr(aria-label)').getall()
        deliverytype =  response.css('.a-row span::attr(aria-label)').getall()
        items['ratings'] = []
     
        
        
        for modelname in modelName:
            if ('\n' not in modelname):
                items['modelName'].append(modelname.split('(')[0])
                
            

        for d in data:
            if ('stars' in d):
                items['ratings'].append(d.split(' ')[0])
                
        filename = f'EDA_WebScrape_Dataset.csv'
        for i in range(len(items['modelName'])-1):
                try:
                    with open(filename,'a') as file:
                        file.write(str(items['modelName'][i].replace(',', '')) + ',' + str(items['price'][i].replace(',', '')) + ',' + str(items['ratings'][i]))
                        file.write('\n')
                except:
                    pass
                    
        yield items
        
        

        next_page = 'https://www.amazon.in/s?i=electronics&bbn=1389401031&rh=n%3A1389401031%2Cp_89%3ARedmi%7CSamsung&dc&page='+ str(QuotesSpider.page_number)  +'&qid=1611378467&rnid=3837712031&ref=sr_pg_2'
        
        
        
        if QuotesSpider.page_number <= 36:
            yield response.follow(next_page, callback = self.parse)
            QuotesSpider.page_number += 1
        